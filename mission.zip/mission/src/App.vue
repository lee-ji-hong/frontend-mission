<template>
  <router-view />
</template>

<style>
* {
  margin: 0;
  text-decoration: none;
  color: inherit; /* 링크의 색상 제거 */
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
